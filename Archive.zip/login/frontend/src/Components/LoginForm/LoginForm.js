import React, { useState } from 'react'
import './LoginForm.css'
import { useNavigate } from 'react-router-dom';
import { FaUser, FaLock } from "react-icons/fa";

const LoginForm = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [emailError, setEmailError] = useState('');
    const [passwordError, setPasswordError] = useState('');
    const navigate = useNavigate();

    const onButtonClick = async (e) => {
        e.preventDefault();

        setEmailError('');
        setPasswordError('');

        if (password.trim() === '') {
            setPasswordError("The password can't be empty");
            return;
        }

        const regex = /^[\w-\.]+@[\w-]+\.[\w-]{2,4}$/;

        if (!regex.test(email)) {
            setEmailError('Please enter a valid email');
            return;
        }

        if (!/[0-9]/.test(password)) {
            setPasswordError("The password should contain at least one number");
            return
        }

        const response = await fetch('http://localhost:3001/auth', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        })

        const data = await response.json();

        if (data.status) {
            navigate(`/congratulations/${email}`);
        } else {
            window.alert("The user doesn't exist");
            navigate('/login');
        }
    }

    return (
        <div className='wrapper'>
            <form action="" onSubmit={onButtonClick}>
                <h1>Login</h1>
                <div className="input-box">
                    <input
                        type="text"
                        placeholder='Email'
                        onChange={(event) => setEmail(event.target.value)}
                        required
                    />
                    <FaUser className='icon' />
                </div>
                <label className="error-message">{emailError}</label>
                <div className="input-box">
                    <input
                        type="password"
                        placeholder='Password'
                        onChange={(event) => setPassword(event.target.value)}
                        required
                    />
                    <FaLock className='icon' />            
                </div>
                <label className="error-message">{passwordError}</label>
                <div className="remember-forgot">
                    <label> <input type="checkbox"/> Remember me </label>
                    <a href='#'>Forgot password?</a>
                </div>

                <button>Login</button>
                <div className="register-link">
                    <p>Don't have an account? <a href='#'>Register</a></p>
                </div>
            </form>
        </div>
    )
}

export default LoginForm