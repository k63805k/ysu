import React from 'react'
import './Congratulations.css'
import { useNavigate, useLocation, useParams } from 'react-router-dom';

const Congratulations = () => {

  const navigate = useNavigate();
  const { email } = useParams();

  // const location = useLocation();
  // const searchParams = new URLSearchParams(location.search);
  // const email = searchParams.get('email');

  const onButtonClick = () => {
    navigate('/');
  };
  
  return (
    <div className='wrapper'>
        <h1>Congratulations, {email}! <br />
        You have successfully logged in</h1>
        <button type="submit" onClick={onButtonClick}>Logout</button>
    </div>
  )
}
  
export default Congratulations