import React from 'react'
import './HomePage.css'
import { AiOutlineHome } from "react-icons/ai";
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
  const navigate = useNavigate();

  const buttonNavigate = (path) => {
    navigate(path);
  };
  
  return (
    <div className='wrapper'>
      <h1>Welcome!</h1>
      <div className='icon-container'>
        <AiOutlineHome className='icon' />
      </div>
      <button type="submit" onClick={() => buttonNavigate('/login')}>Login</button>
      <button type="submit" onClick={() => buttonNavigate('/about-us')}>About us</button>
    </div>
  )
}
  
export default HomePage