import React from 'react'
import './AboutUs.css'
import { useNavigate, useLocation, useParams } from 'react-router-dom';

const AboutUs = () => {

  const navigate = useNavigate();
  
  const buttonNavigate = (path) => {
    navigate(path);
  };
  
  return (
    <div className='wrapper'>
        <h1>About Us </h1>
        <button type="submit" onClick={() => buttonNavigate('/')}>Home page</button>
    </div>
  )
}
  
export default AboutUs