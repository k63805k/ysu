// import logo from './logo.svg';
// import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import HomePage from './Components/HomePage/HomePage';
import AboutUs from './Components/AboutUs/AboutUs';
import LoginForm from './Components/LoginForm/LoginForm';
import Congratulations from './Components/Congratulations/Congratulations';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about-us" element={<AboutUs />} />
          <Route path="/login" element={<LoginForm />} />
          <Route path="/congratulations/:email" element={<Congratulations />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
