import fs from "fs"
import path from "path"
import express from "express";
import cors from "cors"
import bcrypt, { hash } from "bcrypt"
import db from "./db.json" assert { type: 'json' };
import jwt from "jsonwebtoken"

const app = express();
const users = db.users;

const SECRET_KEY = "my_secret_key";
const saltRounds = 10;

//Function to run once on application startup
// const hashing = () => {
//   users.forEach((user) => {
//     const plainPassword = user.password;
//     bcrypt.hash(plainPassword, saltRounds, (err, hashedPassword) => {
//       if (err) {
//         console.error('Error:', err);
//         // Handle error
//       } else {
//         // Store hashedPassword in your database
//         console.log('Hashed Password:', hashedPassword);
//         //user.hashedPassword = hashedPassword;
//       }
//     });
//   })
// };

// hashing();

app.use(cors());
app.use(express.json())

app.get('/', (_req, res) => {
  res.send('Auth API.\nPlease use POST /auth for authentication')
});

app.post('/auth', async (req, res) => {
  function getDate() {
    const today = new Date();
    const d = today.getDate();
    const m = today.getMonth() + 1; // Months are from [0, 11]
    const y = today.getFullYear();
    return (d + '-' + m + '-' + y);
  }
    
  const fileName = getDate(); // get 4-6-2024 for example
  const filePath = path.resolve(`./log/${fileName}.txt`);

  await fs.appendFile(filePath, '', (err) => {
    if (err) throw err;
    console.log('The log is saved successfully!');
  }); // creating file if doesn't exist

  const { email, password } = req.body;

  const user = users.find(user => user.email === email);

  console.log("The password", password);
  console.log("User", user);

  if (!user) {
    const content = "Email, password: " + email + " " + password + " " + "# Message: Email doesn't exist\n";
    await fs.appendFile(filePath, content, 'utf8', () => {
      console.log('File has been written successfully.');
    });
    res.status(401).send({ error: 'Invalid credentials' });
    return;
  }

  bcrypt.compare(password, user.hashedPassword)
  .then((result) => {
    if (!result) {
      const content = "Email, password: " + email + " " + password + " " + "# Message: Password doesn't match" + "\n";
      fs.appendFile(filePath, content, 'utf8', () => {
        console.log('File has been written successfully.');
      });
      res.status(401).send({ error: 'Invalid credentials' });
      return;
    } else {
      const content = "Email, password: " + email + " " + password + " " + "# Message: Successfully logged in" + "\n";
      fs.appendFile(filePath, content, 'utf8', (error) => {
        console.log('File has been written successfully.');
      });
      // Generate a JWT token
      const token = jwt.sign({ email: user.email }, SECRET_KEY, { expiresIn: '1h' });
      res.send({
        status: true,
      })
    }
  })
  .catch((err) => {
    console.log(err);
    throw err;
  })

 
});

const port = 3001;  
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});