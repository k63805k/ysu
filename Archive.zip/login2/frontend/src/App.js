import { useEffect } from "react";
import './App.css';



function App() {

  useEffect(() => {
    fetch("/test")
      .then((resp) => resp.json())
      .then((data) => {
        JSON.stringify(data,null,null);
      })
  }, []);


  return (
    <div>
      Response From React!!!
    </div>
  );
}

export default App;
