import express from "express";
import path from "path";

const app = express();
app.use(express.json());

app.get('/',(req,res)=>{
    res.send('Response from backend');
    console.log(req.url);
})


const __dirname = path.resolve();
console.log(__dirname);
console.log(path.join(__dirname,'newdir'))

app.get('/test',(req,res)=>{
    res.send({
        id:"1",
        fName:"Karen",
        lName:"Hakobjanyan"
    });
    console.log(req.url);
})

app.listen(process.env.PORT || 4445);