import React from 'react'

const HomePage = () => {

  return (
    <div className='wrapper'>
      <h1>Welcome!</h1>
      <div className='icon-container'>
      </div>
      <button type="submit">Login</button>
      {/* <button type="submit" onClick={() => buttonNavigate('/about-us')}>About us</button> */}
    </div>
  )
}
  
export default HomePage